import "./signup.css"
import { FaEnvelope } from "@react-icons/all-files/fa/FaEnvelope";
import { FaUser } from "@react-icons/all-files/fa/FaUser";
import { FaKey } from "@react-icons/all-files/fa/FaKey";
import { Link, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify"
// import { useNavigation } from "react-router-dom";
import axios from "axios";
import { useState } from "react";


export function SignUp(){
    const {register,handleSubmit,formState:{errors}} =useForm();
    const nav = useNavigate();

    const signupdata =(Data)=>{

        if(Data.password == Data.cpassword ){
            Data.type = "Customer"
            
            axios.post("/signup", Data).then((res)=>{
                    
                    toast.success("User Created Successfully");
                    nav("/login");
            })
        }else{
            toast.warn("Password Dosn't Matched");
            
        }
        
        
    }
    return(
        <div className="main">
            <div className="form">
                <div className="Form-Data">
                    <h1>SIGN UP</h1>
                    <form onSubmit={handleSubmit(signupdata)}>
                        <div className="content">
                            <FaUser className="icons"></FaUser>
                            <input type="text" placeholder="Enter Your Name" {...register("name",{required: true})}/>
                            {errors.name && errors.name.type =="validate" ? <div className="error">Alerady Exits</div> : ""}
                            {errors.name && errors.name.type == "required" ? <div className="error">Please Enter Your Name</div> : ""}
                        </div>
                        <div className="content">
                            <FaEnvelope className="icons"></FaEnvelope>
                            <input type="email" placeholder="Enter Your Email" {...register("email",{required: true})}/>
                            {errors.email && errors.email.type == "required" ? <div className="error">Please Enter Your Email</div> : ""}
                        </div>
                        <div className="content">
                            <FaKey className="icons"></FaKey>
                            <input type="password" placeholder="Enter Your Password" {...register("password",{required: true , minLength:6})}/>
                            {errors.password && errors.password.type =="minLength" ? <div className="error">Please Enter Min 8 Character</div> : ""}
                            {errors.password && errors.password.type == "required" ? <div className="error">Please Enter Your Password</div> : ""}
                        </div>
                        <div className="content">
                        <FaKey className="icons"></FaKey>
                            <input type="password" placeholder="Enter Confirmed Password" {...register("cpassword",{required: true , minLength:6})}/>
                            {errors.password && errors.password.type =="minLength" ? <div className="error">Please Enter Min 8 Character</div> : ""}
                            {errors.password && errors.password.type == "required" ? <div className="error">Please Enter Your Password</div> : ""}
                        </div>
                        <div className="Btns">
                            <button className="btne">SignUp</button>
                        </div>
                    </form>
                </div>
                <div className="img-box">
                    <img src="vector.png"/>
                            <a><Link className="link" to={"/login"}>I Have Already Acount?</Link></a>
                </div>
            </div>
        </div>
    )
}