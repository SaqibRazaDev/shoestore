

import "./login.css"
import { FaEnvelope } from "@react-icons/all-files/fa/FaEnvelope";
import { FaKey } from "@react-icons/all-files/fa/FaKey";
import { Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import axios from "axios";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";



export function Login(){
    
    const dispatch = useDispatch();

    const nav = useNavigate();

    const {register,handleSubmit,formState:{errors}}=useForm();

    const UserLogin =(data)=>{

        axios.post("/login" ,data ).then((res)=>{

            let usermila = res.data;
            let message = res.message

            localStorage.setItem('token', res.data.meratoken);

            dispatch({
                type:"userlogins",
                payload:usermila.UserMila
            });
            
         if(usermila?.UserMila?.type == "admin"){
                toast.success("Wellcome To Dashboard");
                nav("/admindash")
            }else if(usermila?.UserMila?.type == "Customer"){
                toast.success("Wellcome To Dashboard");
                nav("/")
            }
            else if(usermila.message == "User not Found"){
                toast.warning("User Not Find");
            }
        })
    }

    return(
        <div className="main">
            <div className="Form">
                <div className="Form-Data">
                    <h1>LOGIN</h1>
                    <form onSubmit={handleSubmit(UserLogin)} >
                        <div className="content">
                            <FaEnvelope className="icons"></FaEnvelope>
                            <input type="email" placeholder="Enter Your Email" {...register("email",{required: true})}/>
                        </div>
                        <div className="content">
                            <FaKey className="icons"></FaKey>
                            <input type="password" placeholder="Enter Your Password" {...register("password",{required: true})}/>
                        </div>
                        <div className="Btns">
                            <button className="btn">Login</button>
                            <a><Link className="link" to={"/signup"}>Create An Acount?</Link></a>
                        </div>
                    </form>
                </div>
                <div className="img-box">
                    <img src="login.png"/>
                </div>
            </div>
        </div>
    )
}